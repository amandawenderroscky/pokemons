import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { PokemonDetailComponent } from './pokemon-detail.component';
import { Angular2FontawesomeModule } from 'angular2-fontawesome';
import { ActivatedRoute, Router } from '@angular/router';
import { PokemonService } from '../core/services/pokemon.service';
import { AppRoutingModule } from '../app-routing.module';
import { PokemonListComponent } from '../pokemon-list/pokemon-list.component';

describe('PokemonDetailComponent', () => {
  let component: PokemonDetailComponent;
  let fixture: ComponentFixture<PokemonDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PokemonDetailComponent, PokemonListComponent],
      imports: [
        Angular2FontawesomeModule,
        AppRoutingModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PokemonDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create',
    inject([ActivatedRoute, PokemonService, Router], (route: ActivatedRoute, _pokemonService: PokemonService, router: Router) => {
      expect(component).toBeTruthy();
    })
  );
});
