import { Component, OnInit } from '@angular/core';
import { PokemonService } from '../core/services/pokemon.service';
import { Pokemon } from '../core/models/pokemon.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-pokemon-detail',
  templateUrl: './pokemon-detail.component.html',
  styleUrls: ['./pokemon-detail.component.scss']
})
export class PokemonDetailComponent implements OnInit {

  id: number;
  sub: Subscription;
  pokemon: Pokemon;
  search: string;

  constructor(private route: ActivatedRoute, private _pokemonService: PokemonService, private router: Router) { }


  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; 
      this.search = params['search']; 
      const param = this.id ? this.id : this.search;

      this._pokemonService.getPokemonDetail(param).subscribe(pokemon => {
        this.pokemon = pokemon;
        
      });
    });
  }

  goToPokemonsList() {
    this.router.navigate(['/pokemons']);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
