import { Component, OnInit } from '@angular/core';
import { Pokemon } from '../core/models/pokemon.model';
import { PokemonService } from '../core/services/pokemon.service';
import { of, Subscription } from 'rxjs';
import { ListResult } from '../core/models/list-result.model';
import { Page } from '../pagination/page.model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon-list.component.html',
  styleUrls: ['./pokemon-list.component.scss']
})
export class PokemonListComponent implements OnInit {

  lista: ListResult;
  
  search: string;
  page: Page;
  sub: Subscription;

  constructor(private _pokemonService: PokemonService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.page = new Page();
    this.page.limit = 10;
    this.page.offset = 0;
    this.page.actualPage = 1;

    this.sub = this.route.params.subscribe(params => {
      this.search = params['search']; 
    });

    this.paginateList();
  }

  listPokemons(){
    this._pokemonService.getAllPokemons(this.search, this.page.offset, this.page.actualPage, this.page.limit).subscribe(res => {
      this.lista = new ListResult();
          
      this.lista.total = res.count;
      this.page.total = this.lista.total;
      this.lista.next = res.next;
      this.lista.previous = res.previous;
  
      this._pokemonService.getPokemonsDetails(res.results).subscribe((pokemons:Pokemon[]) => {
        this.lista.pokemonsList = pokemons;
      });
  
     });
  }

  paginateList(){
    this.listPokemons();
  }

  favoritePokemon(pokemon: Pokemon, isFavorite: boolean){
    this._pokemonService.setFavorite(pokemon, isFavorite);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
