import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { NavbarComponent } from './navbar/navbar.component';
import { AppComponent } from './app.component';
import { Angular2FontawesomeModule } from 'angular2-fontawesome';
import { HttpClientModule } from '@angular/common/http';
import { PokemonService } from './core/services/pokemon.service';
import { LocalStorageModule } from 'angular-2-local-storage';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientModule,
        Angular2FontawesomeModule,
        LocalStorageModule.forRoot({
          prefix: 'pokemons',
          storageType: 'localStorage'
        })
      ],
      declarations: [
        AppComponent,
        NavbarComponent
      ],
      providers: [PokemonService]
    }).compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});
